﻿using System;
using System.Linq;

public static class Calculator
{
    public static int CalculateSum(string numbers, char separator = ',')
    {
        if (string.IsNullOrWhiteSpace(numbers))
            return 0;

        var parts = numbers.Split(separator)
                          .Select(s => s.Trim())
                          .Where(s => !string.IsNullOrEmpty(s))
                          .Take(5)
                          .ToArray();

        if (parts.Length == 0)
            return 0;

        int sum = 0;
        bool hasNegative = false;

        foreach (var part in parts)
        {
            if (!int.TryParse(part, out int number))
            {
                throw new ArgumentException($"Invalid number format: '{part}'");
            }

            if (number < 0)
            {
                hasNegative = true;
                continue;
            }

            if (number <= 10)
            {
                sum += number;
            }
        }

        return hasNegative ? 0 : sum;
    }
}