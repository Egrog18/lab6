﻿using Xunit;
using System;

public class CalculatorTests
{
    [Fact]
    public void CalculateSum_EmptyString_ReturnsZero()
    {
        // Arrange
        var input = "";
        
        // Act
        var result = Calculator.CalculateSum(input);
        
        // Assert
        Assert.Equal(0, result);
    }

    [Fact]
    public void CalculateSum_NormalNumbers_ReturnsCorrectSum()
    {
        // Arrange
        var input = "3,8,4,2,7";
        
        // Act
        var result = Calculator.CalculateSum(input);
        
        // Assert
        Assert.Equal(24, result); // 3+8+4+2+7 = 24
    }

    [Fact]
    public void CalculateSum_NumbersWithCustomSeparator_ReturnsCorrectSum()
    {
        // Arrange
        var input = "3;8;4;2;7";
        
        // Act
        var result = Calculator.CalculateSum(input, ';');
        
        // Assert
        Assert.Equal(24, result);
    }

    [Fact]
    public void CalculateSum_NumbersGreaterThan10_AreSkipped()
    {
        // Arrange
        var input = "3,11,4,15,7";
        
        // Act
        var result = Calculator.CalculateSum(input);
        
        // Assert
        Assert.Equal(14, result); // 3+4+7 = 14 \ 11 и 15 пропущены
    }

    [Fact]
    public void CalculateSum_MoreThan5Numbers_OnlyFirst5Considered()
    {
        // Arrange
        var input = "1,2,3,4,5,6,7,8";
        
        // Act
        var result = Calculator.CalculateSum(input);
        
        // Assert
        Assert.Equal(15, result); // 1+2+3+4+5 = 15; 6,7,8 игнорируются
    }

    [Fact]
    public void CalculateSum_NegativeNumber_ReturnsZero()
    {
        // Arrange
        var input = "3,8,-4,2,7";
        
        // Act
        var result = Calculator.CalculateSum(input);
        
        // Assert
        Assert.Equal(0, result); // Т.к. в строке есть отрицательное число, возвращаем 0
    }

    [Fact]
    public void CalculateSum_InvalidCharacters_ThrowsException()
    {
        // Arrange
        var input = "3,8,abc,2,7";
        
        // Act & Assert
        Assert.Throws<ArgumentException>(() => Calculator.CalculateSum(input));
    }

    [Fact]
    public void CalculateSum_OnlyNumbersGreaterThan10_ReturnsZero()
    {
        // Arrange
        var input = "11,12,13,14,15";
        
        // Act
        var result = Calculator.CalculateSum(input);
        
        // Assert
        Assert.Equal(0, result); // Все числа >10 
    }

    [Fact]
    public void CalculateSum_WithSpacesAroundNumbers_ReturnsCorrectSum()
    {
        // Arrange
        var input = " 3 , 8 , 4 , 2 , 7 ";
        
        // Act
        var result = Calculator.CalculateSum(input);
        
        // Assert
        Assert.Equal(24, result); // Пробелы игнорируются
    }

    [Fact]
    public void CalculateSum_WithEmptyElements_ReturnsCorrectSum()
    {
        // Arrange
        var input = "3,,8,,4,2,7";
        
        // Act
        var result = Calculator.CalculateSum(input);
        
        // Assert
        Assert.Equal(24, result); // Пустые элементы игнорируются
    }
}